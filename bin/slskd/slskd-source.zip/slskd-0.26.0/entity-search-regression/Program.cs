using System.Reflection;
using System.Text.Json;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using slskd.Search;
using slskd.Search.API;
using Soulseek;

SQLitePCL.Batteries.Init();
using var connection = new SqliteConnection("Data Source=:memory:");
connection.Open();
var options = new DbContextOptionsBuilder<SearchDbContext>().UseSqlite(connection).Options;
var factory = new ContextFactory(options);
using (var context = factory.CreateDbContext()) context.Database.EnsureCreated();
var hub = new CaptureHub();
var client = DispatchProxy.Create<ISoulseekClient, FakeClient>();
var fake = (FakeClient)(object)client;
var service = new SearchService(hub, null, client, factory);
var id = Guid.NewGuid();
await service.StartAsync(id, SearchQuery.FromText("Artist Song"), SearchScope.Network);
var emitted = await hub.Response.Task.WaitAsync(TimeSpan.FromSeconds(2));
var json = JsonSerializer.SerializeToElement(emitted, new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase });
if (json.GetProperty("searchId").GetGuid() != id || json.GetProperty("response").GetProperty("files")[0].GetProperty("filename").GetString() != "Artist\\Song.flac") throw new Exception("Live response identity/metadata failed");
var active = await service.FindAsync(search => search.Id == id, includeResponses: true);
if (active.EndedAt != null || active.Responses.Any()) throw new Exception("Response was not delivered before finalization");
service.Update(active with { FileCount = 1 });
var updated = await service.FindAsync(search => search.Id == id, includeResponses: true);
if (updated.FileCount != 1) throw new Exception("Search persistence lost an update");
service.TryCancel(id);
slskd.Search.Search finished = null;
for (var attempt = 0; attempt < 100; attempt++) {
    finished = await service.FindAsync(search => search.Id == id, includeResponses: true);
    if (finished.EndedAt != null) break;
    await Task.Delay(20);
}
if (finished.EndedAt == null || finished.Responses.Single().Files.Single().Filename != "Artist\\Song.flac") throw new Exception("Cancellation lost saved responses");
var lateSearch = new Soulseek.Search(SearchQuery.FromText("Artist Song"), SearchScope.Network, 1, SearchStates.Requested, 0, 0, 0);
fake.Options.StateChanged((SearchStates.Completed, lateSearch));
fake.Options.ResponseReceived((lateSearch, new SearchResponse("offline-peer", 1, true, 1000, 0, new[] { new Soulseek.File(1, "Artist\\Late.flac", 1024, "flac") })));
var preserved = await service.FindAsync(search => search.Id == id, includeResponses: true);
if (preserved.EndedAt == null || preserved.Responses.Single().Files.Single().Filename != "Artist\\Song.flac") throw new Exception("Late callbacks corrupted finalized responses");
await service.DeleteAsync(finished);
service.Update(finished);
if (await service.FindAsync(search => search.Id == id) != null) throw new Exception("Late update recreated a deleted search");
var cancelledClient = DispatchProxy.Create<ISoulseekClient, FakeClient>();
var cancelledFake = (FakeClient)(object)cancelledClient;
var cancelledService = new SearchService(new CaptureHub(), null, cancelledClient, factory);
var cancelledId = Guid.NewGuid();
cancelledFake.OnStart = () => cancelledService.TryCancel(cancelledId);
await cancelledService.StartAsync(cancelledId, SearchQuery.FromText("Artist Song"), SearchScope.Network);
slskd.Search.Search cancelled = null;
for (var attempt = 0; attempt < 100; attempt++) {
    cancelled = await cancelledService.FindAsync(search => search.Id == cancelledId, includeResponses: true);
    if (cancelled.EndedAt != null) break;
    await Task.Delay(20);
}
if (cancelled.EndedAt == null || !cancelled.State.HasFlag(SearchStates.Cancelled)) throw new Exception("Cancellation before scheduling skipped finalization");
Console.WriteLine(JsonSerializer.Serialize(new { passed = true, nativeSearchPublishesBeforeCompletion = true, cancellationPersistsResults = true,
    lateCallbacksPreserveResults = true, deletedSearchNeverRecreated = true, immediateCancellationFinalizes = true,
    searchStates = Enum.GetValues<SearchStates>().ToDictionary(value => value.ToString(), value => (int)value) }));

public class FakeClient : DispatchProxy {
    public SearchOptions Options;
    public Action OnStart;
    readonly TaskCompletionSource<Soulseek.Search> completion = new(TaskCreationOptions.RunContinuationsAsynchronously);
    protected override object Invoke(MethodInfo method, object[] arguments) {
        if (method.Name == "GetNextToken") return 1;
        if (method.Name == "SearchAsync") {
            Options = arguments.OfType<SearchOptions>().Single();
            var response = new SearchResponse("offline-peer", 1, true, 1000, 0, new[] { new Soulseek.File(1, "Artist\\Song.flac", 1024, "flac") });
            arguments.OfType<Action<SearchResponse>>().Single()(response);
            arguments.OfType<CancellationToken>().Single().Register(() => completion.TrySetCanceled());
            OnStart?.Invoke();
            return completion.Task;
        }
        throw new NotSupportedException(method.Name);
    }
}
public class ContextFactory(DbContextOptions<SearchDbContext> options) : IDbContextFactory<SearchDbContext> {
    public SearchDbContext CreateDbContext() => new(options);
}
public class CaptureHub : IHubContext<SearchHub> {
    public TaskCompletionSource<object> Response { get; } = new(TaskCreationOptions.RunContinuationsAsynchronously);
    public IHubClients Clients { get; }
    public IGroupManager Groups => throw new NotSupportedException();
    public CaptureHub() {
        Clients = DispatchProxy.Create<IHubClients, FakeHubClients>();
        ((FakeHubClients)(object)Clients).Proxy = new CaptureProxy(Response);
    }
}
public class FakeHubClients : DispatchProxy {
    public IClientProxy Proxy;
    protected override object Invoke(MethodInfo method, object[] arguments) => Proxy;
}
public class CaptureProxy(TaskCompletionSource<object> response) : IClientProxy {
    public Task SendCoreAsync(string method, object[] arguments, CancellationToken cancellationToken = default) {
        if (method == "RESPONSE") response.TrySetResult(arguments[0]);
        return Task.CompletedTask;
    }
}
