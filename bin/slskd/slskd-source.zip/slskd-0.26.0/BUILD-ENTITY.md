# slskd for Entity

This directory includes slskd 0.26.0, distributed under GNU AGPL v3.
Upstream: https://github.com/slskd/slskd/tree/0.26.0
The corresponding modified source is included in `slskd-source.zip`.
Web participants can download it via the "slskd 소스" link in the footer.

Changes made for Entity on 2026-10-10:

- In DownloadService.cs, open downloads with FileShare.Read | FileShare.Delete so the original FLAC bytes can be served while downloading on Windows.
- In slskd.csproj, explicitly pin SQLitePCLRaw.lib.e_sqlite3 to 3.53.3 to update the bundled native SQLite library.

Changes made for Entity on 2026-10-11:

- In SearchService.cs, publish received peer responses through the existing authenticated search SignalR hub before the search finishes. Hub delivery failures do not interrupt the search or its final REST results.
- In SearchHub.cs, serialize those live responses using the same flattened response model as the REST API. No new public endpoint is added.

Changes made for Entity on 2026-10-13:

- Serialize each search’s state/response persistence with finalization; late callbacks cannot clear saved responses or reopen a completed record.
- Ignore updates only when a search record was already removed, without recreating it or hiding other database failures.
- Always schedule finalization, even when cancellation arrived before the background task started.
- Include an offline regression executable in entity-search-regression. It covers live delivery, completed-response preservation, deletion races and immediate cancellation, without a Soulseek account.

Run the native regression check with `dotnet run --project entity-search-regression/entity-search-regression.csproj -c Release -p:RunAnalyzersDuringBuild=false`.

To reproduce the included self-contained win-x64 binary, extract the source ZIP,
install Microsoft .NET SDK 10, and run from the extracted slskd-0.26.0 directory:

```powershell
dotnet publish src/slskd/slskd.csproj -c Release -r win-x64 --self-contained true -p:RunAnalyzersDuringBuild=false -o entity-build
```

No global .NET SDK is required to run the distributed executable.
The AGPL license text is included as LICENSE. Third-party dependencies retain their own licenses.
