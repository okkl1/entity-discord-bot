// <copyright file="FilesystemDirectory.cs" company="JP Dillingham">
//           ▄▄▄▄     ▄▄▄▄     ▄▄▄▄
//     ▄▄▄▄▄▄█  █▄▄▄▄▄█  █▄▄▄▄▄█  █
//     █__ --█  █__ --█    ◄█  -  █
//     █▄▄▄▄▄█▄▄█▄▄▄▄▄█▄▄█▄▄█▄▄▄▄▄█
//   ┍━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ ━━━━ ━  ━┉   ┉     ┉
//   │ Copyright (c) JP Dillingham.
//   │
//   │ This program is free software: you can redistribute it and/or modify
//   │ it under the terms of the GNU Affero General Public License as published
//   │ by the Free Software Foundation, version 3.
//   │
//   │ This program is distributed in the hope that it will be useful,
//   │ but WITHOUT ANY WARRANTY; without even the implied warranty of
//   │ MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   │ GNU Affero General Public License for more details.
//   │
//   │ You should have received a copy of the GNU Affero General Public License
//   │ along with this program.  If not, see https://www.gnu.org/licenses/.
//   │
//   │ This program is distributed with Additional Terms pursuant to Section 7
//   │ of the AGPLv3.  See the LICENSE file in the root directory of this
//   │ project for the complete terms and conditions.
//   │
//   │ https://slskd.org
//   │
//   ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌ ╌ ╌╌╌╌ ╌
//   │ SPDX-FileCopyrightText: JP Dillingham
//   │ SPDX-License-Identifier: AGPL-3.0-only
//   ╰───────────────────────────────────────────╶──── ─ ─── ─  ── ──┈  ┈
// </copyright>

namespace slskd.Files
{
    using System;
    using System.Collections.Generic;
    using System.IO;

    /// <summary>
    ///     A file directory on the host filesystem.
    /// </summary>
    public record FilesystemDirectory
    {
        /// <summary>
        ///     The name of the directory.
        /// </summary>
        public string Name { get; init; }

        /// <summary>
        ///     The fully qualified name of the directory.
        /// </summary>
        public string FullName { get; init; }

        /// <summary>
        ///     The directories' attributes.
        /// </summary>
        public FileAttributes Attributes { get; init; }

        /// <summary>
        ///     The timestamp at which the directory was created.
        /// </summary>
        public DateTime CreatedAt { get; init; }

        /// <summary>
        ///     The timestamp at which the directory was last modified.
        /// </summary>
        public DateTime ModifiedAt { get; init; }

        /// <summary>
        ///     The files within the directory.
        /// </summary>
        public IEnumerable<FilesystemFile> Files { get; init; }

        /// <summary>
        ///     The directories within the directory.
        /// </summary>
        public IEnumerable<FilesystemDirectory> Directories { get; init; }

        /// <summary>
        ///     Maps a <see cref="FilesystemDirectory"/> from the specified <see cref="DirectoryInfo"/>.
        /// </summary>
        /// <param name="i">The DirectoryInfo instance from which to map.</param>
        /// <returns>A new instance of FilesystemDirectory.</returns>
        public static FilesystemDirectory FromDirectoryInfo(DirectoryInfo i)
        {
            return new FilesystemDirectory
            {
                Name = i.Name,
                FullName = i.FullName,
                Attributes = i.Attributes,
                CreatedAt = i.CreationTimeUtc,
                ModifiedAt = i.LastWriteTimeUtc,
            };
        }
    }
}
