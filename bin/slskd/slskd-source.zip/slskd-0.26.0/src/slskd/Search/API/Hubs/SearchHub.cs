// <copyright file="SearchHub.cs" company="JP Dillingham">
//           ▄▄▄▄     ▄▄▄▄     ▄▄▄▄
//     ▄▄▄▄▄▄█  █▄▄▄▄▄█  █▄▄▄▄▄█  █
//     █__ --█  █__ --█    ◄█  -  █
//     █▄▄▄▄▄█▄▄█▄▄▄▄▄█▄▄█▄▄█▄▄▄▄▄█
//   ┍━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ ━━━━ ━  ━┉   ┉     ┉
//   │ Copyright (c) JP Dillingham.
//   │
//   │ This program is free software: you can redistribute it and/or modify
//   │ it under the terms of the GNU Affero General Public License as published
//   │ by the Free Software Foundation, version 3.
//   │
//   │ This program is distributed in the hope that it will be useful,
//   │ but WITHOUT ANY WARRANTY; without even the implied warranty of
//   │ MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   │ GNU Affero General Public License for more details.
//   │
//   │ You should have received a copy of the GNU Affero General Public License
//   │ along with this program.  If not, see https://www.gnu.org/licenses/.
//   │
//   │ This program is distributed with Additional Terms pursuant to Section 7
//   │ of the AGPLv3.  See the LICENSE file in the root directory of this
//   │ project for the complete terms and conditions.
//   │
//   │ https://slskd.org
//   │
//   ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌ ╌ ╌╌╌╌ ╌
//   │ SPDX-FileCopyrightText: JP Dillingham
//   │ SPDX-License-Identifier: AGPL-3.0-only
//   ╰───────────────────────────────────────────╶──── ─ ─── ─  ── ──┈  ┈
// </copyright>

namespace slskd.Search.API
{
    using System;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.SignalR;

    public static class SearchHubMethods
    {
        public static readonly string List = "LIST";
        public static readonly string Create = "CREATE";
        public static readonly string Response = "RESPONSE";
        public static readonly string Update = "UPDATE";
        public static readonly string Delete = "DELETE";
    }

    /// <summary>
    ///     Extension methods for the search SignalR hub.
    /// </summary>
    public static class SearchHubExtensions
    {
        /// <summary>
        ///     Broadcast an update for a search.
        /// </summary>
        /// <remarks>
        ///     Responses are removed prior to sending.
        /// </remarks>
        /// <param name="hub">The hub.</param>
        /// <param name="search">The search to broadcast.</param>
        /// <returns>The operation context.</returns>
        public static Task BroadcastUpdateAsync(this IHubContext<SearchHub> hub, Search search)
        {
            return hub.Clients.All.SendAsync(SearchHubMethods.Update, search with { Responses = null });
        }

        /// <summary>
        ///     Broadcast a newly received search response.
        /// </summary>
        /// <param name="hub">The hub.</param>
        /// <param name="searchId">The ID of the search associated with the response.</param>
        /// <param name="response">The response to broadcast.</param>
        /// <returns>The operation context.</returns>
        public static Task BroadcastResponseAsync(this IHubContext<SearchHub> hub, Guid searchId, Soulseek.SearchResponse response)
        {
            return hub.Clients.All.SendAsync(SearchHubMethods.Response, new { searchId, response = slskd.Search.Response.FromSoulseekSearchResponse(response) });
        }

        /// <summary>
        ///     Broadcast the creation of a new search.
        /// </summary>
        /// <remarks>
        ///     Responses are removed prior to sending.
        /// </remarks>
        /// <param name="hub">The hub.</param>
        /// <param name="search">The search to broadcast.</param>
        /// <returns>The operation context.</returns>
        public static Task BroadcastCreateAsync(this IHubContext<SearchHub> hub, Search search)
        {
            return hub.Clients.All.SendAsync(SearchHubMethods.Create, search with { Responses = null });
        }

        /// <summary>
        ///     Broadcast the deletion of a search.
        /// </summary>
        /// <remarks>
        ///     Responses are removed prior to sending.
        /// </remarks>
        /// <param name="hub">The hub.</param>
        /// <param name="search">The search to broadcast.</param>
        /// <returns>The operation context.</returns>
        public static Task BroadcastDeleteAsync(this IHubContext<SearchHub> hub, Search search)
        {
            return hub.Clients.All.SendAsync(SearchHubMethods.Delete, search with { Responses = null });
        }
    }

    /// <summary>
    ///     The search SignalR hub.
    /// </summary>
    [Authorize(Policy = AuthPolicy.Any)]
    public class SearchHub : Hub
    {
        public SearchHub(
            ISearchService searchService)
        {
            Searches = searchService;
        }

        private ISearchService Searches { get; }

        public override async Task OnConnectedAsync()
        {
            var searches = await Searches.ListAsync();
            await Clients.Caller.SendAsync(SearchHubMethods.List, searches);
        }
    }
}
