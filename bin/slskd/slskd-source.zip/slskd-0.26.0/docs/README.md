# Documentation

## Quick Start

### [System Requirements](https://github.com/slskd/slskd/blob/master/docs/system_requirements.md)
### [Known Issues](https://github.com/slskd/slskd/blob/master/docs/known_issues.md)

## Configuring slskd

### [Application Configuration](https://github.com/slskd/slskd/blob/master/docs/config.md)

## Running slskd

### [In Docker](https://github.com/slskd/slskd/blob/master/docs/docker.md)
### [With a VPN](https://github.com/slskd/slskd/blob/master/docs/vpn.md)
### [Behind a Reverse Proxy](https://github.com/slskd/slskd/blob/master/docs/reverse_proxy.md)
### [In Relay Mode](https://github.com/slskd/slskd/blob/master/docs/relay.md)

## Building slskd from Source

### [Build](https://github.com/slskd/slskd/blob/master/docs/build.md)

## Troubleshooting

### [Migrations](https://github.com/slskd/slskd/blob/master/docs/migrations.md)